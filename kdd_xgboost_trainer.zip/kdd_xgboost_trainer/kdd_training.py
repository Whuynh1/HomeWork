import datetime
import os
import subprocess
import sys
import pandas as pd
import pandas as pd
import xgboost as xgb

from sklearn import preprocessing
le = preprocessing.LabelEncoder()

# Fill in your Cloud Storage bucket name
BUCKET_NAME = 'bucket'

kdd_data_filename = 'NewFile.txt'
kdd_target_filename = 'type.txt'

# gsutil outputs everything to stderr so we need to divert it to stdout.
subprocess.check_call(['gsutil', 'cp', kdd_data_filename,
                       kdd_data_filename], stderr=sys.stdout)
subprocess.check_call(['gsutil', 'cp', kdd_target_filename,
                       kdd_target_filename], stderr=sys.stdout)
# [END download-data]

kdd_data = pd.read_csv(kdd_data_filename).values
kdd_target = pd.read_csv(kdd_target_filename).values


kdd_data_filename = kdd_target_filename.reshape((kdd_target_filename.size,))
le.fit(kdd_target_filename)
print(list(le.classes_))
kdd_target = le.transform(kdd_target)
print("Our new labels are:")
print(kdd_target)

dtrain = xgb.Dmatrix(kdd_data_filename, label = kdd_target_filename)

bst = xgb.train({}, dtrain, 20)

# Export the classifier to a file
model_filename = 'model.bst'
bst.save_model(model_filename)
# [END train-and-save-model]

gcs_model_path = os.path.join('gs://', BUCKET_NAME,
    datetime.datetime.now().strftime('iris_%Y%m%d_%H%M%S'), model_filename)
subprocess.check_call(['gsutil', 'cp', model_filename, gcs_model_path],
    stderr=sys.stdout)

